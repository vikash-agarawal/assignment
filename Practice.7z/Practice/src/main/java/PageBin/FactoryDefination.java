package PageBin;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class FactoryDefination {
	
	WebDriver driver;
	
	@FindBy(how=How.NAME,using="userName")
	@CacheLookup
	WebElement pfUserName;

	
	@FindBy(how=How.NAME,using="userPwd")
	@CacheLookup
	WebElement pfPassword;
	

	@FindBy(how=How.CLASS_NAME,using="btn")
	@CacheLookup
	WebElement pfButton;


	public FactoryDefination(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}


	public WebElement getPfButton() {
		return pfButton;
	}


	public void setPfButton() {
		pfButton.click();
	}


	public WebElement getPfUserName() {
		return pfUserName;
	}


	public WebElement getPfPassword() {
		return pfPassword;
	}



	public void setPfUserName(String sUserName) {
		pfUserName.sendKeys(sUserName);;
	}


	public void setPfPassword(String sPassword) {
		pfPassword.sendKeys(sPassword);;
	}

	
	
	
	
	
	
	

}
